import 'package:flutter/material.dart';
import 'package:logsheet_app/features/admin/pages/master_mastervalue.dart';
import '../auth/login_page.dart';
import 'pages/master_user.dart';
import 'pages/master_business_unit.dart';
import 'pages/quality_report/quality_report_wizard.dart';
import 'pages/quality_report/quality_report_data.dart';
import 'pages/quality_report/quality_report_status.dart';

// import 'pages/quality_report/quality_report_main.dart';

class AdminHomePage extends StatefulWidget {
  final String userName;
  final astronautBlue = const Color(0xFF00336E);
  const AdminHomePage({super.key, required this.userName});

  @override
  State<AdminHomePage> createState() => _AdminHomePageState();
}

class _AdminHomePageState extends State<AdminHomePage> {
  Future<void> _logout() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Konfirmasi Logout'),
            content: const Text('Apakah Anda yakin ingin logout?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: const Text('Batal'),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                ),
                onPressed: () => Navigator.of(context).pop(true),
                child: const Text(
                  'Logout',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
    );

    if (confirm == true && mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const LoginPage()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEFF3F9),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 1,
        iconTheme: const IconThemeData(color: Colors.black87),
        title: const Text(
          'Admin Panel',
          style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold),
        ),
      ),
      drawer: Drawer(
        backgroundColor: Colors.white,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue.shade100),
              child: Row(
                children: const [
                  Icon(
                    Icons.admin_panel_settings,
                    size: 40,
                    color: Colors.blue,
                  ),
                  SizedBox(width: 12),
                  Text(
                    'Admin Menu',
                    style: TextStyle(
                      color: Colors.black87,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.dashboard_outlined),
              title: const Text('Dashboard'),
              onTap: () {
                Navigator.pop(context); // Tutup drawer
                // Navigasi ke halaman dashboard jika perlu
              },
            ),
            ExpansionTile(
              leading: const Icon(Icons.settings_applications_outlined),
              title: const Text('Master'),
              iconColor: Colors.blue,
              collapsedIconColor: Colors.grey,
              children: <Widget>[
                ListTile(
                  contentPadding: const EdgeInsets.only(left: 40.0),
                  leading: const Icon(Icons.person_outline),
                  title: const Text('User Management'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => MstUserPage(userName: widget.userName),
                        settings: const RouteSettings(name: 'MstUserPage'),
                      ),
                    );
                  },
                ),
                ListTile(
                  contentPadding: const EdgeInsets.only(left: 40.0),
                  leading: const Icon(Icons.category_outlined),
                  title: const Text('Business Unit'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder:
                            (_) =>
                                MstBusinessUnitPage(userName: widget.userName),
                        settings: const RouteSettings(
                          name: 'MstBusinessUnitPage',
                        ),
                      ),
                    );
                  },
                ),
                ListTile(
                  contentPadding: const EdgeInsets.only(left: 40.0),
                  leading: const Icon(Icons.storage_outlined),
                  title: const Text('Master Values'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder:
                            (_) =>
                                MstMastervaluePage(userName: widget.userName),
                        settings: const RouteSettings(
                          name: 'MstMastervaluePage',
                        ),
                      ),
                    );
                    // Navigasi ke halaman Data Storage
                  },
                ),
              ],
            ),
            ExpansionTile(
              leading: const Icon(Icons.description),
              title: const Text('Transaction'),
              iconColor: Colors.blue,
              collapsedIconColor: Colors.grey,
              children: <Widget>[
                // SUBMENU UTAMA: Quality Refinery (dengan ExpansionTile lagi)
                ExpansionTile(
                  leading: const Icon(Icons.insert_chart_outlined),
                  title: const Text('Quality Refinery'),
                  childrenPadding: const EdgeInsets.only(left: 60.0),
                  children: [
                    ListTile(
                      leading: const Icon(Icons.analytics_outlined),
                      title: const Text('Input Data'),
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder:
                                (_) => QualityReportRefineryPage(
                                  userName: widget.userName,
                                ),
                            settings: const RouteSettings(
                              name: 'QualityReportPage',
                            ),
                          ),
                        );
                      },
                    ),
                    ListTile(
                      leading: const Icon(Icons.science_outlined),
                      title: const Text('Report'),
                      onTap: () {
                        Navigator.pop(context);
                        // Ganti halaman ini sesuai kebutuhan
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder:
                                (_) =>
                                    QualityListPage(userName: widget.userName),
                            settings: const RouteSettings(
                              name: 'LabReportPage',
                            ),
                          ),
                        );
                      },
                    ),
                    ListTile(
                      leading: const Icon(Icons.info),
                      title: const Text('Status'),
                      onTap: () {
                        Navigator.pop(context);
                        // Ganti halaman ini sesuai kebutuhan
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder:
                                (_) => StatusPage(userName: widget.userName),
                            settings: const RouteSettings(
                              name: 'LabReportPage',
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),

                // ListTile lainnya tetap seperti sebelumnya
                ListTile(
                  contentPadding: const EdgeInsets.only(left: 40.0),
                  leading: const Icon(Icons.category_outlined),
                  title: const Text('Filtration Refinery'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder:
                            (_) =>
                                MstBusinessUnitPage(userName: widget.userName),
                        settings: const RouteSettings(
                          name: 'MstBusinessUnitPage',
                        ),
                      ),
                    );
                  },
                ),
                ListTile(
                  contentPadding: const EdgeInsets.only(left: 40.0),
                  leading: const Icon(Icons.storage_outlined),
                  title: const Text('Preatreatment & Bleaching'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder:
                            (_) => QualityReportRefineryPage(
                              userName: widget.userName,
                            ),
                        settings: const RouteSettings(
                          name: 'MstMastervaluePage',
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),

            ListTile(
              leading: const Icon(Icons.settings),
              title: const Text('Settings'),
              onTap: () {
                Navigator.pop(context);
                // Navigasi ke halaman Settings
              },
            ),
            const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.redAccent),
              title: const Text(
                'Logout',
                style: TextStyle(color: Colors.redAccent),
              ),
              onTap: _logout,
            ),
          ],
        ),
      ),
      body: Center(
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 24),
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            boxShadow: const [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 16,
                offset: Offset(0, 6),
              ),
            ],
          ),
          child: Text(
            'Welcome, ${widget.userName}!',
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
              letterSpacing: 1.1,
            ),
          ),
        ),
      ),
    );
  }
}
