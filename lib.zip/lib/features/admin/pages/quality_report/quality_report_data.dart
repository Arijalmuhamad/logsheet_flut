import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../../../core/database/app_database.dart';
import '../../../../data/dao/quality_report_refinery_dao.dart';

class QualityListPage extends StatefulWidget {
  final String userName;
  const QualityListPage({super.key, required this.userName});

  @override
  State<QualityListPage> createState() => _QualityListPageState();
}

class _QualityListPageState extends State<QualityListPage> {
  late final AppDatabase db;
  late final QualityReportRefineryDao qualityReportRefDao;

  String? _selectedHour;
  String? _tempSelectedHour;
  DateTime? _selectedDate;

  bool isLoading = false;

  TextEditingController dateController = TextEditingController();

  List<TQualityReportRefineryData> allData = [];
  List<TQualityReportRefineryData> filteredData = [];

  int _currentPage = 0;
  final int _rowsPerPage = 10;

  final List<String> _hours = List.generate(
    24,
    (index) => '${index.toString().padLeft(2, '0')}:00',
  );

  @override
  void initState() {
    super.initState();
    db = AppDatabase();
    qualityReportRefDao = QualityReportRefineryDao(db);
    _selectedDate = DateTime.now();
    _loadData();
  }

  Future<void> _loadData() async {
    final data = await qualityReportRefDao.getAllQualityReportsRefinery();
    setState(() {
      allData = data;
    });
    _filterData(); // langsung filter dengan tanggal hari ini
  }

  void _resetForm() {
    dateController.clear();
    _selectedDate = DateTime.now();
    _tempSelectedHour = null;
    _selectedHour = null;
    _filterData();
  }

  Future<void> _refreshPage() async {
    setState(() => isLoading = true);
    await Future.delayed(const Duration(milliseconds: 600));
    _resetForm();
    setState(() => isLoading = false);
  }

  void _filterData() {
    setState(() {
      filteredData =
          allData.where((item) {
            final itemHour = item.time?.substring(0, 5);
            final matchHour =
                (_selectedHour == null || _selectedHour == 'all')
                    ? true
                    : itemHour == _selectedHour;
            final matchDate =
                _selectedDate == null ||
                DateFormat('yyyy-MM-dd').format(item.report_date) ==
                    DateFormat('yyyy-MM-dd').format(_selectedDate!);
            return matchHour && matchDate;
          }).toList();
      _currentPage = 0;
    });
  }

  Future<void> _pickDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() {
        _selectedDate = picked;
        dateController.text = DateFormat('yyyy-MM-dd').format(picked);
      });
    }
  }

  List<TQualityReportRefineryData> get paginatedData {
    int start = _currentPage * _rowsPerPage;
    int end = (start + _rowsPerPage).clamp(0, filteredData.length);
    return filteredData.sublist(start, end);
  }

  @override
  Widget build(BuildContext context) {
    int totalPages = (filteredData.length / _rowsPerPage).ceil();

    return Scaffold(
      backgroundColor: const Color(0xFFEFF3F9),
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text(
          'Quality Data List',
          style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _refreshPage),
        ],
        centerTitle: true,
        elevation: 1,
      ),
      body: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: dateController,
                        readOnly: true,
                        decoration: InputDecoration(
                          hintText: 'Pilih tanggal',
                          filled: true,
                          fillColor: Colors.white,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 12,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                        ),
                        onTap: () => _pickDate(context),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: DropdownButtonFormField<String?>(
                        isExpanded: true,
                        value: _tempSelectedHour,
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.white,
                          hintText: "Pilih jam",
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 12,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                        ),
                        items: [
                          const DropdownMenuItem<String?>(
                            value: 'all',
                            child: Text('all'),
                          ),
                          ..._hours.map(
                            (hour) => DropdownMenuItem<String?>(
                              value: hour,
                              child: Text(hour),
                            ),
                          ),
                        ],
                        onChanged: (value) {
                          setState(() {
                            _tempSelectedHour = value;
                          });
                        },
                      ),
                    ),
                    const SizedBox(width: 10),
                    ElevatedButton.icon(
                      onPressed: () {
                        setState(() {
                          _selectedHour = _tempSelectedHour;
                          _filterData();
                        });
                      },
                      icon: const Icon(Icons.search),
                      label: const Text('Cari Data'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF007BFF),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 14,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    elevation: 2,
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: const [
                          BoxShadow(
                            color: Colors.black12,
                            blurRadius: 4,
                            offset: Offset(0, 2),
                          ),
                        ],
                      ),
                      padding: const EdgeInsets.all(8),
                      child:
                          filteredData.isEmpty
                              ? const Center(
                                child: Text(
                                  'Tidak ada data',
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.grey,
                                  ),
                                ),
                              )
                              : SingleChildScrollView(
                                scrollDirection: Axis.vertical,
                                child: SingleChildScrollView(
                                  scrollDirection: Axis.horizontal,
                                  child: DataTable(
                                    columnSpacing: 30,
                                    headingRowColor: WidgetStateProperty.all(
                                      Colors.white,
                                    ),
                                    headingTextStyle: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black87,
                                    ),
                                    columns: const [
                                      DataColumn(
                                        label: Center(child: Text('No')),
                                      ),
                                      DataColumn(
                                        label: Center(child: Text('Tanggal')),
                                      ),
                                      DataColumn(
                                        label: Center(child: Text('Jam')),
                                      ),
                                      DataColumn(
                                        label: Center(child: Text('Shift')),
                                      ),
                                      DataColumn(
                                        label: Center(child: Text('Flowrate')),
                                      ),
                                      DataColumn(
                                        label: Center(child: Text('FFA')),
                                      ),
                                      DataColumn(
                                        label: Center(child: Text('IV')),
                                      ),
                                      DataColumn(
                                        label: Center(child: Text('PV')),
                                      ),
                                      DataColumn(
                                        label: Center(child: Text('DOBI')),
                                      ),
                                      DataColumn(
                                        label: Center(child: Text('Carotene')),
                                      ),
                                      DataColumn(
                                        label: Center(child: Text('Color R')),
                                      ),
                                      DataColumn(
                                        label: Center(child: Text('Color Y')),
                                      ),
                                      DataColumn(
                                        label: Center(child: Text('Aksi')),
                                      ),
                                    ],
                                    rows: List.generate(paginatedData.length, (
                                      index,
                                    ) {
                                      final item = paginatedData[index];
                                      final isEven = index % 2 == 0;
                                      return DataRow(
                                        color: WidgetStateProperty.all(
                                          isEven
                                              ? Colors.grey.shade100
                                              : Colors.white,
                                        ),
                                        cells: [
                                          DataCell(
                                            Center(
                                              child: Text(
                                                '${_currentPage * _rowsPerPage + index + 1}',
                                              ),
                                            ),
                                          ),
                                          DataCell(
                                            Center(child: Text(item.tanggal)),
                                          ),
                                          DataCell(
                                            Center(
                                              child: Text(
                                                item.time?.substring(0, 5) ??
                                                    '-',
                                              ),
                                            ),
                                          ),
                                          DataCell(
                                            Center(child: Text(item.shift)),
                                          ),
                                          DataCell(
                                            Center(
                                              child: Text(
                                                item.p_flowrate
                                                        ?.toStringAsFixed(2) ??
                                                    '-',
                                              ),
                                            ),
                                          ),
                                          DataCell(
                                            Center(
                                              child: Text(
                                                item.p_ffa?.toStringAsFixed(
                                                      2,
                                                    ) ??
                                                    '-',
                                              ),
                                            ),
                                          ),
                                          DataCell(
                                            Center(
                                              child: Text(
                                                item.p_iv?.toStringAsFixed(2) ??
                                                    '-',
                                              ),
                                            ),
                                          ),
                                          DataCell(
                                            Center(
                                              child: Text(
                                                item.p_pv?.toStringAsFixed(2) ??
                                                    '-',
                                              ),
                                            ),
                                          ),
                                          DataCell(
                                            Center(
                                              child: Text(
                                                item.p_dobi?.toStringAsFixed(
                                                      2,
                                                    ) ??
                                                    '-',
                                              ),
                                            ),
                                          ),
                                          DataCell(
                                            Center(
                                              child: Text(
                                                item.p_carotene
                                                        ?.toStringAsFixed(2) ??
                                                    '-',
                                              ),
                                            ),
                                          ),
                                          DataCell(
                                            Center(
                                              child: Text(
                                                item.b_color_r?.toString() ??
                                                    '-',
                                              ),
                                            ),
                                          ),
                                          DataCell(
                                            Center(
                                              child: Text(
                                                item.b_color_y?.toString() ??
                                                    '-',
                                              ),
                                            ),
                                          ),
                                          DataCell(
                                            Center(
                                              child: Row(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  Tooltip(
                                                    message: 'Edit',
                                                    child: IconButton(
                                                      icon: const Icon(
                                                        Icons.edit,
                                                        color: Colors.blue,
                                                      ),
                                                      onPressed: () {},
                                                    ),
                                                  ),
                                                  Tooltip(
                                                    message: 'Hapus',
                                                    child: IconButton(
                                                      icon: const Icon(
                                                        Icons.delete,
                                                        color: Colors.red,
                                                      ),
                                                      onPressed: () {},
                                                    ),
                                                  ),
                                                  Tooltip(
                                                    message: 'Detail',
                                                    child: IconButton(
                                                      icon: const Icon(
                                                        Icons.info,
                                                        color: Colors.green,
                                                      ),
                                                      onPressed:
                                                          () => _onTapRow(item),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ],
                                      );
                                    }),
                                  ),
                                ),
                              ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text('Page ${_currentPage + 1} of $totalPages'),
                      IconButton(
                        onPressed:
                            _currentPage > 0
                                ? () => setState(() => _currentPage--)
                                : null,
                        icon: const Icon(Icons.arrow_back_ios),
                      ),
                      IconButton(
                        onPressed:
                            _currentPage < totalPages - 1
                                ? () => setState(() => _currentPage++)
                                : null,
                        icon: const Icon(Icons.arrow_forward_ios),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (isLoading)
            Container(
              color: Colors.black45,
              child: const Center(child: CircularProgressIndicator()),
            ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 100,
            child: Text(
              '$label:',
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                color: Colors.black87,
              ),
            ),
          ),
          Expanded(
            child: Text(value, style: const TextStyle(color: Colors.black54)),
          ),
        ],
      ),
    );
  }

  void _onTapRow(TQualityReportRefineryData item) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            title: const Text(
              'Detail Data',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Divider(),
                  _buildDetailRow('Tanggal', item.tanggal),
                  _buildDetailRow('Jam', item.time?.substring(0, 5) ?? '-'),
                  _buildDetailRow('Shift', item.shift),
                  _buildDetailRow(
                    'Flowrate',
                    item.p_flowrate?.toStringAsFixed(2) ?? '-',
                  ),
                  _buildDetailRow('FFA', item.p_ffa?.toStringAsFixed(2) ?? '-'),
                  _buildDetailRow('IV', item.p_iv?.toStringAsFixed(2) ?? '-'),
                  _buildDetailRow('PV', item.p_pv?.toStringAsFixed(2) ?? '-'),
                  _buildDetailRow(
                    'DOBI',
                    item.p_dobi?.toStringAsFixed(2) ?? '-',
                  ),
                  _buildDetailRow(
                    'Carotene',
                    item.p_carotene?.toStringAsFixed(2) ?? '-',
                  ),
                  _buildDetailRow('Color R', item.b_color_r?.toString() ?? '-'),
                  _buildDetailRow('Color Y', item.b_color_y?.toString() ?? '-'),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text(
                  'Tutup',
                  style: TextStyle(color: Colors.blue),
                ),
              ),
            ],
          ),
    );
  }
}

extension QualityDataExtension on TQualityReportRefineryData {
  String get shift {
    final hourStr = time?.split(":").first;
    final hour = int.tryParse(hourStr ?? '');
    if (hour == null) return '-';
    if (hour >= 7 && hour < 15) return '1';
    if (hour >= 15 && hour < 23) return '2';
    return '3';
  }

  String get tanggal => DateFormat('yyyy-MM-dd').format(report_date);
}
