// import 'dart:js_interop';
// ignore_for_file: use_build_context_synchronously
import 'package:drift/drift.dart' as drift;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:logger/logger.dart';
import 'package:logsheet_app/core/database/app_database.dart';
import 'package:logsheet_app/data/dao/quality_report_refinery_dao.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../../../../core/providers/user_provider.dart';

class QualityReportRefineryPage extends StatefulWidget {
  final String userName;
  const QualityReportRefineryPage({super.key, required this.userName});
  @override
  State<QualityReportRefineryPage> createState() =>
      _QualityReportRefineryPageState();
}

class _QualityReportRefineryPageState extends State<QualityReportRefineryPage> {
  late final AppDatabase db;
  late final QualityReportRefineryDao qualityReportRefDao;

  double? selectedTankSource;
  int? selectedHour;
  String? selectedPart; // part category
  String? selectedCcat; // chemical category
  String? selectedBcat; // bpo category
  String? selectedRcat; // rpo category
  String? selectedFPcat; // rfad catergory

  String? entryBy;
  String? checkedBy;
  int currentStep = 0;
  bool isLoading = false;

  // Part (CPO/CPKO) Input
  final TextEditingController pflowRateController = TextEditingController();
  final TextEditingController pffaController = TextEditingController();
  final TextEditingController pivController = TextEditingController();
  final TextEditingController ppvController = TextEditingController();
  final TextEditingController panVController = TextEditingController();
  final TextEditingController pdobiController = TextEditingController();
  final TextEditingController pcaroteneController = TextEditingController();
  final TextEditingController pmnIController = TextEditingController();
  final TextEditingController pcolorController = TextEditingController();

  // Chemical Input
  final TextEditingController chempaController = TextEditingController();
  final TextEditingController chembeController = TextEditingController();

  // BPO Input
  final TextEditingController bpocolorRController = TextEditingController();
  final TextEditingController bpocolorYController = TextEditingController();
  final TextEditingController bpobtController = TextEditingController();

  // RPO Input
  final TextEditingController rpoffaController = TextEditingController();
  final TextEditingController rpocolorRController = TextEditingController();
  final TextEditingController rpocolorYController = TextEditingController();
  final TextEditingController rpocolorBController = TextEditingController();
  final TextEditingController rpopvController = TextEditingController();
  final TextEditingController rpomnIController = TextEditingController();
  final TextEditingController rpoproductController =
      TextEditingController(); // (tank) inputan list dari master

  // RFAD Input
  final TextEditingController pfadpurityController = TextEditingController();
  final TextEditingController pfadproductController =
      TextEditingController(); // (tank) inputan list dari master

  // Spent Earth OIC input
  final TextEditingController spenoicController = TextEditingController();

  // Remaks Input
  final TextEditingController remarkController = TextEditingController();

  List<TQualityReportRefineryData> qualityReportsRefinery = [];
  TQualityReportRefineryData? editingQualityReportsRefinery;

  final logger = Logger();

  @override
  void initState() {
    super.initState();
    db = AppDatabase();
    qualityReportRefDao = QualityReportRefineryDao(db);
    // _loadQualityReport();
  }

  // Future<void> _loadQualityReport() async {
  //   final data = await qualityReportRefDao.getAllQualityReportsRefinery();
  //   setState(() => qualityReportsRefinery = data);
  // }

  void _resetForm() {
    selectedTankSource = null; // Selected Tank Source
    selectedHour = null; // Selected time
    selectedPart = null; // part category
    selectedCcat = null; // chemical category
    selectedBcat = null; // bpo category
    selectedRcat = null; // rpo category
    selectedFPcat = null; // rfad catergory

    // Part input
    pflowRateController.clear();
    pffaController.clear();
    pivController.clear();
    ppvController.clear();
    panVController.clear();
    pdobiController.clear();
    pcaroteneController.clear();
    pmnIController.clear();
    pcolorController.clear();

    // Chemical Input
    chempaController.clear();
    chembeController.clear();

    // BPO Input
    bpocolorRController.clear();
    bpocolorYController.clear();
    bpobtController.clear();

    // RPO Input
    rpoffaController.clear();
    rpocolorRController.clear();
    rpocolorYController.clear();
    rpocolorBController.clear();
    rpopvController.clear();
    rpomnIController.clear();
    rpoproductController.clear();

    // RFAD Input
    pfadpurityController.clear();
    pfadproductController.clear();

    // Spent Earth OIC Input
    spenoicController.clear();

    // Remarks Input
    remarkController.clear();
  }

  @override
  void dispose() {
    // CPO Input
    pflowRateController.dispose();
    pffaController.dispose();
    pivController.dispose();
    ppvController.dispose();
    panVController.dispose();
    pdobiController.dispose();
    pcaroteneController.dispose();
    pmnIController.dispose();
    pcolorController.dispose();

    // Chemical Input
    chempaController.dispose();
    chembeController.dispose();

    // BPO Input
    bpocolorRController.dispose();
    bpocolorYController.dispose();
    bpobtController.dispose();

    // RPO Input
    rpoffaController.dispose();
    rpocolorRController.dispose();
    rpocolorYController.dispose();
    rpocolorBController.dispose();
    rpopvController.dispose();
    rpomnIController.dispose();
    rpoproductController.dispose();

    // RFAD Input
    pfadpurityController.dispose();
    pfadproductController.dispose();

    // Spent Earth
    spenoicController.dispose();

    // Remark
    remarkController.dispose();

    super.dispose();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final userProvider = Provider.of<UserProvider>(context, listen: false);
    if (entryBy == null && userProvider.userName.isNotEmpty) {
      setState(() {
        entryBy = userProvider.userName;
      });
    }
  }

  Future<void> _refreshPage() async {
    setState(() => isLoading = true);
    await Future.delayed(const Duration(milliseconds: 600));
    _resetForm();
    currentStep = 0;
    setState(() => isLoading = false);
  }

  // void _showSnackbar(String message) {
  //   ScaffoldMessenger.of(context).showSnackBar(
  //     SnackBar(
  //       content: Text(message),
  //       behavior: SnackBarBehavior.floating,
  //       backgroundColor: Colors.black87,
  //       duration: const Duration(seconds: 3),
  //     ),
  //   );
  // }

  bool isSaving = false;

  Future<void> _saveQualityReport() async {
    if (isSaving) return;
    setState(() => isSaving = true);

    final tanksource = selectedTankSource;
    final ppart = selectedPart;
    final userProvider = Provider.of<UserProvider>(context, listen: false);
    final uuid = Uuid();

    final String formattedTime =
        selectedHour != null
            ? '${selectedHour.toString().padLeft(2, '0')}.00'
            : '';

    // 🔍 Validasi wajib
    if (tanksource == null || formattedTime.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Mohon lengkapi Tank Source dan Jam Input')),
      );
      setState(() => isSaving = false);
      return;
    }

    double? parseDouble(TextEditingController c) {
      final text = c.text.trim();
      return text.isEmpty ? null : double.tryParse(text);
    }

    try {
      // ✅ Gunakan satu reportId untuk header dan detail
      final reportId = editingQualityReportsRefinery?.id ?? uuid.v4();
      // BPO
      final bpocolorR = bpocolorRController.text.trim();
      final bpocolorY = bpocolorYController.text.trim();
      // RPO
      final rpocolorR = rpocolorRController.text.trim();
      final rpocolorY = rpocolorYController.text.trim();
      final rpocolorB = rpocolorBController.text.trim();
      final rpopv = rpopvController.text.trim();
      final rpomni = rpomnIController.text.trim();

      final qualityreport = TQualityReportRefineryCompanion(
        id: drift.Value(reportId),
        // Report basic info
        report_date: drift.Value(DateTime.now()),
        time: drift.Value(formattedTime),
        // Parameters
        p_cat: drift.Value(ppart),
        p_tank_source: drift.Value(tanksource),
        p_flowrate: drift.Value(parseDouble(pflowRateController)),
        p_ffa: drift.Value(parseDouble(pffaController)),
        p_iv: drift.Value(parseDouble(pivController)),
        p_pv: drift.Value(parseDouble(ppvController)),
        p_anv: drift.Value(parseDouble(panVController)),
        p_dobi: drift.Value(parseDouble(pdobiController)),
        p_carotene: drift.Value(parseDouble(pcaroteneController)),
        p_m_i: drift.Value(parseDouble(pmnIController)),
        p_color: drift.Value(pcolorController.text.trim()),
        // Chemical & BPO
        c_cat: drift.Value(null),
        c_pa: drift.Value(parseDouble(chempaController)),
        c_be: drift.Value(parseDouble(chembeController)),
        b_color_r:
            bpocolorR.isEmpty
                ? const drift.Value.absent()
                : drift.Value(int.tryParse(bpocolorR) ?? 0),
        b_color_y:
            bpocolorY.isEmpty
                ? const drift.Value.absent()
                : drift.Value(int.tryParse(bpocolorY) ?? 0),
        b_break_test: drift.Value(bpobtController.text.trim()),
        // RPO
        r_cat: drift.Value(null),
        r_ffa: drift.Value(parseDouble(rpoffaController)),
        r_color_r:
            rpocolorR.isEmpty
                ? const drift.Value.absent()
                : drift.Value(int.tryParse(rpocolorR)),
        r_color_y:
            rpocolorY.isEmpty
                ? const drift.Value.absent()
                : drift.Value(int.parse(rpocolorY)),
        r_color_b:
            rpocolorB.isEmpty
                ? const drift.Value.absent()
                : drift.Value(int.parse(rpocolorB)),
        r_pv:
            rpopv.isEmpty
                ? const drift.Value.absent()
                : drift.Value(int.parse(rpopv)),
        r_m_i:
            rpomni.isEmpty
                ? const drift.Value.absent()
                : drift.Value(int.parse(rpopv)),
        r_product_tank_no: drift.Value(parseDouble(rpoproductController)),
        // PFAD
        fp_cat: drift.Value(null),
        fp_purity: drift.Value(parseDouble(pfadpurityController)),
        fp_product_tank_no: drift.Value(parseDouble(pfadproductController)),
        // Spent Earth
        spent_earth_oic: drift.Value(parseDouble(spenoicController)),
        // Meta Data
        pic: drift.Value(userProvider.userName),
        remarks: drift.Value(remarkController.text.trim()),
        checked_by:
            checkedBy == null
                ? const drift.Value.absent()
                : drift.Value(checkedBy),
        checked_date: drift.Value(null),
        checked_time: drift.Value(null),
        approved_by: drift.Value(null),
        approved_date: drift.Value(null),
        approved_time: drift.Value(null),

        // System
        flag: drift.Value('T'),
        company: drift.Value(null),
        plant: drift.Value(null),
        entry_by: drift.Value(userProvider.userName),
        entry_date: drift.Value(DateTime.now()),
      );

      await qualityReportRefDao.insertQualityReportRefinery(qualityreport);

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Laporan berhasil disimpan ✅')));
      Navigator.pop(context); // atau reset form, sesuai kebutuhan
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Gagal menyimpan laporan: $e')));
    } finally {
      setState(() => isSaving = false);
    }
  }

  void _nextStep() {
    if (currentStep < 3) {
      setState(() => currentStep++);
    }
  }

  void _prevStep() {
    if (currentStep > 0) {
      setState(() => currentStep--);
    }
  }

  // void _saveData() {
  //   ScaffoldMessenger.of(
  //     context,
  //   ).showSnackBar(const SnackBar(content: Text('Data berhasil disimpan')));
  // }

  void _showHourPicker(BuildContext context) {
    int initialHour = selectedHour ?? TimeOfDay.now().hour;

    // 🛠 Set default selectedHour sebelum picker tampil
    selectedHour = initialHour;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (BuildContext context) {
        return SizedBox(
          height: 300,
          child: Column(
            children: [
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text(
                  'Pilih Jam Input',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              Expanded(
                child: CupertinoPicker(
                  itemExtent: 40,
                  scrollController: FixedExtentScrollController(
                    initialItem: initialHour,
                  ),
                  onSelectedItemChanged: (int value) {
                    selectedHour = value;
                  },
                  children: List.generate(
                    24,
                    (index) => Center(
                      child: Text('${index.toString().padLeft(2, '0')}:00'),
                    ),
                  ),
                ),
              ),
              TextButton(
                onPressed: () {
                  setState(() {});
                  Navigator.pop(context);
                },
                child: const Text('Pilih'),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    String? hintText,
    bool isNumeric = false, // ⬅️ Tambahan untuk membedakan input angka/teks
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: TextField(
        controller: controller,
        keyboardType:
            isNumeric
                ? const TextInputType.numberWithOptions(decimal: true)
                : TextInputType.text,
        inputFormatters:
            isNumeric
                ? [FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*'))]
                : [],
        decoration: InputDecoration(
          labelText: label,
          hintText: hintText,
          prefixIcon: Icon(icon),
          filled: true,
          fillColor: const Color(0xFFF5F8FA),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }

  String getStepTitle() {
    switch (currentStep) {
      case 0:
        if (selectedPart == 'CPO') return 'CPO Parameters';
        if (selectedPart == 'CPKO') return 'CPKO Parameters';
        return 'Parameters'; // default
      case 1:
        if (selectedPart == 'CPO') return 'Chemcical & BPO';
        if (selectedPart == 'CPKO') return 'Chemcical & BPKO';
        return 'Parameters';
      case 2:
        return 'RPO Parameters';
      case 3:
        return 'RFAD, Spent Earth, & Remaks';
      default:
        return '';
    }
  }

  Widget _buildStepContent() {
    switch (currentStep) {
      case 0:
        return Column(
          children: [
            _buildTextField(
              controller: pflowRateController,
              label: 'Flow Rate',
              icon: Icons.speed,
              isNumeric: true,
              hintText: 'Masukkan nilai Flow Rate (MT)',
            ),
            _buildTextField(
              controller: pffaController,
              label: 'FFA',
              icon: Icons.bubble_chart,
              isNumeric: true,
              hintText: 'Masukkan nilai FFA (%)',
            ),
            _buildTextField(
              controller: pivController,
              label: 'IV',
              icon: Icons.scale,
              isNumeric: true,
              hintText: 'Masukan nilai IV (g/mg)',
            ),
            _buildTextField(
              controller: ppvController,
              label: 'PV',
              icon: Icons.energy_savings_leaf,
              isNumeric: true,
              hintText: 'Masukan nilai PV (meq/kg)',
            ),
            _buildTextField(
              controller: panVController,
              label: 'AnV',
              icon: Icons.fact_check,
              isNumeric: true,
              hintText: 'Masukan nilai AnV',
            ),
            _buildTextField(
              controller: pdobiController,
              label: 'DOBI',
              icon: Icons.opacity,
              isNumeric: true,
              hintText: 'Masukan nilai DOBI',
            ),
            _buildTextField(
              controller: pcaroteneController,
              label: 'Carotene',
              icon: Icons.lens,
              isNumeric: true,
              hintText: 'Masukan nilai Carotene',
            ),
            _buildTextField(
              controller: pmnIController,
              label: 'M&I',
              icon: Icons.opacity,
              isNumeric: true,
              hintText: 'Masukan nilai M&I (%)',
            ),
            _buildTextField(
              controller: pcolorController,
              label: 'Color R/Y/B',
              icon: Icons.color_lens,
              hintText: 'Masukan nilai Color',
            ),
          ],
        );
      case 1:
        return Column(
          // Chemical & BPO Input UI
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "Chemical",
                  style: TextStyle(fontSize: 16),
                  textAlign: TextAlign.left,
                ),
              ),
            ),
            _buildTextField(
              controller: chempaController,
              label: 'PA',
              icon: Icons.science_outlined,
              isNumeric: true,
              hintText: 'Masukkan nilai PA (%)',
            ),
            _buildTextField(
              controller: chembeController,
              label: 'BE',
              icon: Icons.bubble_chart_outlined,
              isNumeric: true,
              hintText: 'Masukkan nilai BE (%)',
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  getStepTitle(),
                  style: TextStyle(fontSize: 16),
                  textAlign: TextAlign.left,
                ),
              ),
            ),

            _buildTextField(
              controller: bpocolorRController,
              label: 'Color R',
              icon: Icons.color_lens,
              isNumeric: true,
              hintText: 'Masukkan nilai Color (R)',
            ),
            _buildTextField(
              controller: bpocolorYController,
              label: 'Color Y',
              icon: Icons.color_lens,
              isNumeric: true,
              hintText: 'Masukkan nilai Color (Y)',
            ),
            _buildTextField(
              controller: bpobtController,
              label: 'Break Test',
              icon: Icons.color_lens,
              hintText: 'Masukkan nilai Break Test',
            ),
          ],
        );
      case 2:
        return Column(
          children: [
            _buildTextField(
              controller: rpoffaController,
              label: 'FFA',
              icon: Icons.bubble_chart,
              isNumeric: true,
              hintText: 'Masukkan nilai FFA %',
            ),
            _buildTextField(
              controller: rpocolorRController,
              label: 'Color R',
              icon: Icons.color_lens,
              isNumeric: true,
              hintText: 'Masukkan nilai Color (R)',
            ),
            _buildTextField(
              controller: rpocolorYController,
              label: 'Color Y',
              icon: Icons.color_lens,
              isNumeric: true,
              hintText: 'Masukkan nilai Color (Y)',
            ),
            _buildTextField(
              controller: rpocolorBController,
              label: 'Color B',
              icon: Icons.color_lens,
              isNumeric: true,
              hintText: 'Masukkan nilai Color (B)',
            ),
            _buildTextField(
              controller: rpopvController,
              label: 'PV',
              icon: Icons.speed,
              isNumeric: true,
              hintText: 'Masukkan nilai PV (meq/kg)',
            ),
            _buildTextField(
              controller: rpomnIController,
              label: 'M & I',
              icon: Icons.science,
              isNumeric: true,
              hintText: 'Masukkan nilai M&I (%)',
            ),
            _buildTextField(
              controller: rpoproductController,
              label: 'Product',
              icon: Icons.local_gas_station,
              isNumeric: true,
              hintText: 'Masukkan nilai Tank No',
            ),
          ],
        );
      case 3:
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "RFAD",
                  style: TextStyle(fontSize: 16),
                  textAlign: TextAlign.left,
                ),
              ),
            ),
            _buildTextField(
              controller: pfadpurityController,
              label: 'Purity',
              icon: Icons.water_drop,
              isNumeric: true,
              hintText: 'Masukkan nilai Purity %',
            ),
            _buildTextField(
              controller: pfadproductController,
              label: 'Product',
              icon: Icons.local_gas_station,
              isNumeric: true,
              hintText: 'Masukkan nilai Tank No',
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "Spent Earth",
                  style: TextStyle(fontSize: 16),
                  textAlign: TextAlign.left,
                ),
              ),
            ),
            _buildTextField(
              controller: spenoicController,
              label: 'Spent Earth',
              icon: Icons.public,
              isNumeric: true,
              hintText: 'Masukkan nilai Spent Erath OIC (%)',
            ),
            _buildTextField(
              controller: remarkController,
              label: 'Remark',
              icon: Icons.note,
              hintText: 'Masukkan nilai Remark',
            ),
          ],
        );
      default:
        return const SizedBox.shrink();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEFF3F9),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 1,
        iconTheme: const IconThemeData(color: Colors.black87),
        title: const Text(
          'Quality Report - Refinery',
          style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _refreshPage),
        ],
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // TANK SOURCE
                DropdownButtonFormField<double>(
                  value: selectedTankSource,
                  items:
                      [10.0, 20.0, 30.0]
                          .map(
                            (tankValue) => DropdownMenuItem<double>(
                              value: tankValue,
                              child: Text(
                                'Tank ${tankValue.toStringAsFixed(0)}',
                              ),
                            ),
                          )
                          .toList(),
                  onChanged:
                      (value) => setState(() => selectedTankSource = value),
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: const Color(0xFFF5F8FA),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                    hintText: 'Pilih tank source',
                    prefixIcon: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: SvgPicture.asset(
                        'assets/icons/oil-refinery-tanks.svg',
                        height: 24,
                        width: 24,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 8),

                // JAM INPUT
                InkWell(
                  onTap: () => _showHourPicker(context),
                  child: InputDecorator(
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: const Color(0xFFF5F8FA),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                      prefixIcon: const Icon(Icons.access_time),
                    ),
                    child: Text(
                      selectedHour != null
                          ? '${selectedHour.toString().padLeft(2, '0')}:00'
                          : 'Pilih jam input',
                      style: TextStyle(
                        color:
                            selectedHour != null
                                ? Colors.black87
                                : Colors.grey.shade600,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 8),

                // PART
                DropdownButtonFormField<String>(
                  value: selectedPart,
                  items:
                      ['CPO', 'CPKO']
                          .map(
                            (part) => DropdownMenuItem(
                              value: part,
                              child: Text(part),
                            ),
                          )
                          .toList(),
                  onChanged: (value) => setState(() => selectedPart = value),
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: const Color(0xFFF5F8FA),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                    hintText: 'Pilih Part',
                    prefixIcon: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: SvgPicture.asset(
                        'assets/icons/category-svgrepo-com.svg',
                        height: 24,
                        width: 24,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 24),

                if (selectedPart != null) ...[
                  // STEP INDICATOR
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(4, (index) {
                      return Container(
                        margin: const EdgeInsets.symmetric(horizontal: 6),
                        width: 24,
                        height: 24,
                        decoration: BoxDecoration(
                          color:
                              currentStep == index
                                  ? const Color(0xFF007BFF)
                                  : Colors.grey.shade300,
                          shape: BoxShape.circle,
                        ),
                        child: Center(
                          child: Text(
                            '${index + 1}',
                            style: TextStyle(
                              color:
                                  currentStep == index
                                      ? Colors.white
                                      : Colors.grey,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      );
                    }),
                  ),

                  const SizedBox(height: 16),

                  // FORM CARD
                  Card(
                    color: Colors.white,
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            getStepTitle(),
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF1E1E1E),
                            ),
                          ),
                          const SizedBox(height: 12),
                          _buildStepContent(),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // BUTTONS
                  Row(
                    children: [
                      if (currentStep > 0)
                        Expanded(
                          child: ElevatedButton.icon(
                            icon: const Icon(Icons.arrow_back),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.grey.shade400,
                              foregroundColor: Colors.black87,
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            onPressed: _prevStep,
                            label: const Text('Back'),
                          ),
                        )
                      else
                        const Spacer(),
                      const SizedBox(width: 16),
                      Expanded(
                        child: ElevatedButton.icon(
                          icon: Icon(
                            currentStep == 3 ? Icons.save : Icons.arrow_forward,
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF007BFF),
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          onPressed:
                              currentStep == 3 ? _saveQualityReport : _nextStep,
                          label: Text(currentStep == 3 ? 'Save' : 'Next'),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),
                ] else ...[
                  // NOTIFIKASI jika belum pilih Part
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 24.0),
                    child: Center(
                      child: Text(
                        'Silakan pilih Part terlebih dahulu.',
                        style: TextStyle(
                          color: Colors.red.shade600,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          if (isLoading)
            Container(
              color: Colors.black26,
              child: const Center(child: CircularProgressIndicator()),
            ),
        ],
      ),
    );
  }
}
