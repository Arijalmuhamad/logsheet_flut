import 'package:logsheet_app/core/database/app_database.dart';

class QualityReportRefineryDao {
  final AppDatabase db;

  QualityReportRefineryDao(this.db);

  Future<List<TQualityReportRefineryData>> getAllQualityReportsRefinery() {
    return db.select(db.tQualityReportRefinery).get();
  }

  Future<void> insertQualityReportRefinery(
    TQualityReportRefineryCompanion unit,
  ) {
    return db.into(db.tQualityReportRefinery).insert(unit);
  }

  Future<void> updateQualityReportRefinery(TQualityReportRefineryData unit) {
    return db.update(db.tQualityReportRefinery).replace(unit);
  }

  Future<void> deleteQualityReportRefinery(String id) {
    return (db.delete(db.tQualityReportRefinery)
      ..where((tbl) => tbl.id.equals(id))).go();
  }
}
